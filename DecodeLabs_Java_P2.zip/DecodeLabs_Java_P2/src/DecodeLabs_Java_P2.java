import java.util.Scanner;

public class DecodeLabs_Java_P2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean continueSession = true;

        System.out.println("==========================================");
        System.out.println("   DECODELABS STUDENT GRADE CALCULATOR    ");
        System.out.println("==========================================");

        do {
            // ========== PHASE I: INPUT ==========
            System.out.print("\nEnter Student Name: ");
            String studentName = sc.nextLine().trim();

            int subjectCount = getValidSubjectCount(sc);
            int totalMarks = 0;

            System.out.println("\n--- Enter Marks (0 - 100) ---");

            for (int i = 1; i <= subjectCount; i++) {
                int mark = getValidMark(sc, i);
                totalMarks += mark;
            }

            // ========== PHASE II: PROCESS ==========
            double average = (double) totalMarks / subjectCount;
            String grade = calculateGrade(average);
            String status = (average >= 50) ? "PASS" : "FAIL";

            // ========== PHASE III: OUTPUT ==========
            System.out.println("\n==========================================");
            System.out.println("            STUDENT REPORT CARD           ");
            System.out.println("==========================================");
            System.out.printf(" Student Name    : %s%n", studentName);
            System.out.printf(" Subjects Taken  : %d%n", subjectCount);
            System.out.printf(" Total Marks     : %d / %d%n", totalMarks, subjectCount * 100);
            System.out.printf(" Average         : %.2f%%%n", average);
            System.out.printf(" Grade           : %s%n", grade);
            System.out.printf(" Status          : %s%n", status);
            System.out.println("==========================================");

            System.out.print("\nCalculate another student? [Y/N]: ");
            String choice = sc.nextLine().trim();
            if (!choice.equalsIgnoreCase("Y")) {
                continueSession = false;
            }

        } while (continueSession);

        System.out.println("\n==========================================");
        System.out.println("   Thank you for using DecodeLabs! 🎓     ");
        System.out.println("==========================================");

        sc.close();
    }

    // Get valid subject count (1 - 20)
    private static int getValidSubjectCount(Scanner sc) {
        while (true) {
            System.out.print("Enter Number of Subjects (1-20): ");
            try {
                String input = sc.nextLine().trim();
                int count = Integer.parseInt(input);
                if (count < 1 || count > 20) {
                    System.out.println("⚠ Subject count must be between 1 and 20.");
                    continue;
                }
                return count;
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter a number.");
            }
        }
    }

    // Get valid mark (0 - 100)
    private static int getValidMark(Scanner sc, int subjectNum) {
        while (true) {
            System.out.printf("Enter marks for Subject %d: ", subjectNum);
            try {
                String input = sc.nextLine().trim();
                int mark = Integer.parseInt(input);

                if (mark < 0 || mark > 100) {
                    System.out.println("⚠ Marks must be between 0 and 100. Try again.");
                    continue;
                }
                return mark;
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter a numeric value.");
            }
        }
    }

    // Logic Ladder (strictest first)
    private static String calculateGrade(double avg) {
        if (avg >= 90) return "A+ (Excellent)";
        else if (avg >= 80) return "A  (Very Good)";
        else if (avg >= 70) return "B  (Good)";
        else if (avg >= 60) return "C  (Average)";
        else if (avg >= 50) return "D  (Pass)";
        else                return "F  (Fail)";
    }
}
